package easynotes;

import easynotes.model.Note;
import easynotes.model.Notes;
import easynotes.utilities.TexParser;

public class Main {
    public static void main(String[] args) {
        //TexParser.test();
//        Notes notes = new Notes();
//        notes.runDirectory("D:\\attr");
//        for(Note note : notes.getNotes()) {
//            note.print();
//            System.out.println("\n");
//        }
//        //notes.saveNotes();
    }
}
