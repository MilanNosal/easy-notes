package easynotes.model;

import java.io.*;
import java.util.*;

public class Note implements Comparable<Note> {
    
    public static final String USED = "used";
    public static final String NEW = "new";
    public static final String DELIM = ";";
    
    private List<String> tags = new LinkedList<>();
    
    private String title;
    
    private String link;
    
    private String text;
    
    private String citations;
    
    public Note(String title, String link, String text, String citations, List<String> tags) {
        this.title = title;
        this.link = link.replace(System.getProperty("file.separator"), "/");
        this.text = text;
        this.citations = citations;
        this.tags = tags;
    }
    
    public static Note readNote(BufferedReader br) {
        String readTitle = readNextSigLine(br);
        if(readTitle==null) {
            return null;
        }
        String readLink = readNextSigLine(br);
        if(readLink==null) {
            return null;
        }
        String readText = readNextSigLine(br);
        if(readText==null) {
            return null;
        }
        String readCitation = readNextSigLine(br);
        if(readCitation==null) {
            return null;
        }
        String readTags = readNextSigLine(br);
        if(readTags==null) {
            return null;
        }
        StringTokenizer st = new StringTokenizer(readTags.trim(), DELIM);
        ArrayList<String> list = new ArrayList<>(st.countTokens());
        while(st.hasMoreTokens()) {
            list.add(st.nextToken().trim());
        }
        return new Note(readTitle, readLink, readText, readCitation, list);
    }
    
    private static String readNextSigLine(BufferedReader br) {
        try {
            String line = br.readLine();
            while (line != null && line.equals("") && !line.startsWith("<<<")) {
                line = br.readLine();
            }
            if (line != null && line.startsWith("<<<")) {
                StringBuilder sb = new StringBuilder();
                line = br.readLine();
                while (line != null && !line.startsWith(">>>")) {
                    sb.append(line).append("\n");
                    line = br.readLine();
                }
                if(line != null && line.startsWith(">>>")) {
                    return sb.toString();
                }
            }
        } catch (IOException ex) {
            System.err.println("Problem while writing to file.");
        }
        return null;
    }

    public String getCitations() {
        return citations;
    }

    public void setCitations(String citations) {
        this.citations = citations;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link.replace(System.getProperty("file.separator"), "/");
    }

    /**
     * Use only for getting, never for setting. Returns copy.
     * @return 
     */
    public String[] getTags() {
        return tags.toArray(new String[tags.size()]);
    }
    
    public void addTag(String tag) {
        tags.add(tag);
    }
    
    public void changeTag(String oldTag, String newTag) {
        tags.set(tags.indexOf(oldTag), newTag);
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    
    public String serialize() {

        StringBuilder builder = new StringBuilder();
        
        builder.append("<<<\n").append(title).append("\n>>>\n");
        builder.append("<<<\n").append(link).append("\n>>>\n");
        builder.append("<<<\n").append(text).append("\n>>>\n");
        builder.append("<<<\n").append(citations).append("\n>>>\n<<<\n");

        for(String tag : tags) {
            builder.append(tag).append(DELIM);
        }
        
        builder.append("\n>>>\n");
        
        return builder.toString();
    }
    
    public void print() {
        try {
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
            bw.write(title);
            bw.newLine();
            bw.newLine();
            bw.write(link);
            bw.newLine();
            bw.newLine();
            bw.write(text);
            bw.newLine();
            bw.newLine();
            bw.write("<<<");
            bw.newLine();
            bw.write(citations);
            bw.newLine();
            bw.write(">>>");
            bw.newLine();
            bw.newLine();
            bw.write("// ");
            for(String tag : tags) {
                bw.write(tag);
                bw.write(DELIM);
            }
            bw.newLine();
            bw.flush();
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }
    
    public boolean isNew() {
        for(String tag : tags) {
            if(tag.equalsIgnoreCase(NEW)) {
                return true;
            }
        }
        return false;
    }
    
    public boolean isUsed() {
        for(String tag : tags) {
            if(tag.equalsIgnoreCase(USED)) {
                return true;
            }
        }
        return false;
    }
    
    public String getBibItem() {
        int index = citations.indexOf("\\bibitem{");
        if(index == -1) {
            return "";
        }
        return citations.substring(index).trim();
    }
    
    public boolean isCited(List<String> citations) {
        String thisCitation = getCitationString();
        for(String citation : citations) {
            if(citation.equals(thisCitation)) {
                return true;
            }
        }
        return false;
    }
    
    private String getCitationString() {
        int index = citations.indexOf("\\cite{");
        if(index == -1) {
            return "";
        }
        String retVal = citations.substring(index+6);
        index = retVal.indexOf("}");
        retVal = retVal.substring(0, index);
        return retVal;
    }

    @Override
    public int compareTo(Note o) {
        boolean thisNew = isNew();
        boolean oNew = o.isNew();
        if (thisNew == true && oNew == false) {
            return -1;
        } else if(oNew == true && thisNew == false) {
            return 1;
        }
        return this.title.compareToIgnoreCase(o.title);
    }
    
    public static class BibItemComparator implements Comparator<Note> {

        private UTFStringComparator utf = new UTFStringComparator();
        
        @Override
        public int compare(Note o1, Note o2) {
            String note1 = o1.getBibItem();
            int index = note1.indexOf("}");
            if(index==-1) {
                note1 = "";
            } else {
                note1 = note1.substring(index).trim();
            }
            String note2 = o2.getBibItem();
            index = note2.indexOf("}");
            if(index==-1) {
                note2 = "";
            } else {
                note2 = note2.substring(index).trim();
            }
            return utf.compare(note1, note2);
        }
    }
}
