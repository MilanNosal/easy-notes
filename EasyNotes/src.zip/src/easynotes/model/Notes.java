package easynotes.model;

import java.io.*;
import java.util.*;
import javax.swing.table.AbstractTableModel;

public class Notes extends AbstractTableModel {

    private List<Note> notes = new LinkedList<>();
    private List<Note> notesToShow = new LinkedList<>();
    private String[] columnNames = new String[]{"Title", "Tags"}; //, "Text"};
    private List<String> currentTags = new LinkedList<>();
    private Set<String> allTags = new HashSet<>();
    private String title;
    private String citation;
    private String text;
    private String notesFile = "notes.note";
    private String encoding = "cp1250";

    public void runDirectory(File notesFile) {

        //File file = new File(path);
        if (!notesFile.exists()) {
            System.err.println("The file " + notesFile.getAbsolutePath() + " does not exist.");
            return;
        }

        try {
            this.notesFile = notesFile.getCanonicalPath();
        } catch (IOException ex) {
            System.err.println("The file " + notesFile.getAbsolutePath() + " has some trouble with canonical path.");
            return;
        }

        BufferedReader br;
        try {
            FileInputStream file = new FileInputStream(notesFile);
            br = new BufferedReader(new InputStreamReader(file, encoding));
        } catch (FileNotFoundException | UnsupportedEncodingException ex) {
            System.err.println("The file " + notesFile.getAbsolutePath() + " does not exist or there is problem with encoding.");
            return;
        }

        Note nextNote = Note.readNote(br);
        while (nextNote != null) {
            notes.add(nextNote);
            this.allTags.addAll(Arrays.asList(nextNote.getTags()));
            nextNote = Note.readNote(br);
        }
        this.updateView();
    }

    public void saveNotes() {
        StringBuilder sb = new StringBuilder();
        for (Note note : notes) {
            sb.append(note.serialize()).append("\n");
        }
        try {
            FileOutputStream fos = new FileOutputStream(notesFile);
            OutputStreamWriter out = new OutputStreamWriter(fos, encoding);
            out.write(sb.toString());
            out.close();
        } catch (IOException ex) {
            System.err.println(ex.getMessage());
        }
    }

    public Note getNoteAt(int index) {
        return this.notesToShow.get(index);
    }

    public void setCitation(String citation) {
        this.citation = citation;
        this.updateView();
    }

    public void setText(String text) {
        this.text = text;
        this.updateView();
    }

    public void setTitle(String title) {
        this.title = title;
        this.updateView();
    }

    public void clearCurrentTags() {
        this.currentTags.clear();
        this.updateView();
    }

    public void setCurrentTags(String... tags) {
        this.currentTags.clear();
        this.currentTags.addAll(Arrays.asList(tags));
        this.updateView();
    }

    public void addCurrentTag(String tag) {
        this.currentTags.add(tag);
        this.updateView();
    }

    public void updateView() {
        this.notesToShow.clear();
        for (Note note : notes) {
            if (notePasses(note)) {
                notesToShow.add(note);
            }
        }
        Collections.sort(notesToShow);
        fireTableStructureChanged();
    }

    public void addNote(Note note) {
        notes.add(note);
        this.allTags.addAll(Arrays.asList(note.getTags()));
        if (notePasses(note)) {
            notesToShow.add(note);
            Collections.sort(notesToShow);
            this.fireTableStructureChanged();
        }
    }

    private boolean notePasses(Note note) {
        if (!notePassesTags(note)) {
            return false;
        }
        if (!notePassesTitle(note)) {
            return false;
        }
        if (!notePassesCitation(note)) {
            return false;
        }
        if (!notePassesText(note)) {
            return false;
        }
        return true;
    }

    private boolean notePassesTitle(Note note) {
        if (title == null) {
            return true;
        }
        if (note.getTitle().toLowerCase().contains(title.toLowerCase())) {
            return true;
        }
        return false;
    }

    private boolean notePassesCitation(Note note) {
        if (citation == null) {
            return true;
        }
        if (note.getCitations().toLowerCase().contains(citation.toLowerCase())) {
            return true;
        }
        return false;
    }

    private boolean notePassesText(Note note) {
        if (text == null) {
            return true;
        }
        if (note.getText().toLowerCase().contains(text.toLowerCase())) {
            return true;
        }
        return false;
    }

    private boolean notePassesTags(Note note) {
        if (!note.isUsed()) {
            if (currentTags.isEmpty()) {
                return true;
            }

            //potrebne aby presiel vsetkymi tagmi, ak tam je ze sa nema rovnat tak ma ho nezobrazit 
            boolean retVal = false;

            for (String part : this.currentTags) {
                if (part.startsWith("!")) {
                    String sub = part.substring(1);
                    for (String tag : note.getTags()) {
                        if (tag.toLowerCase().contains(sub.toLowerCase())) {
                            return false;
                        }
                    }
                    retVal = true;
                } else {
                    for (String tag : note.getTags()) {
                        if (tag.toLowerCase().contains(part.toLowerCase())) {
                            retVal = true;
                        }
                    }
                }
            }
            return retVal;
        } else {
            for (String part : this.currentTags) {
                if (part.toLowerCase().equals(Note.USED)) {
                    return true;
                }
            }
        }
        return false;
    }

    public void updateNoteAt(int index) {
        fireTableRowsUpdated(index, index);
    }

    public void clearNotes() {
        this.currentTags.clear();
        this.notes.clear();
        this.allTags.clear();
        this.notesToShow.clear();
        fireTableStructureChanged();
    }

    @Override
    public String getColumnName(int col) {
        return columnNames[col].toString();
    }

    @Override
    public int getRowCount() {
        return notesToShow.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return notesToShow.get(rowIndex).getTitle();
            case 1:
                StringBuilder sb = new StringBuilder();
                for (String tag : notesToShow.get(rowIndex).getTags()) {
                    sb.append(tag);
                    sb.append(";");
                }
                return sb.toString();
//            case 2:
//                return notesToShow.get(rowIndex).getText();
            default:
                return null;
        }
    }

    public Set<String> getAllTags() {
        return this.allTags;
    }

    public String getBibliographyFor(List<String> citations) {
        StringBuilder bib = new StringBuilder("");
        List<Note> notesBib = new ArrayList<>(this.notes);
        Collections.sort(notesBib, new Note.BibItemComparator());
        for (Note note : notesBib) {
            if (note.isCited(citations)) {
                bib.append(note.getBibItem()).append("\n");
            }
        }
        return bib.toString();
    }
}
