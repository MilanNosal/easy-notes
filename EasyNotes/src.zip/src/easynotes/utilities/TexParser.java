package easynotes.utilities;

import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Milan
 */
public class TexParser {

    private static final Pattern pattern = Pattern.compile("\\\\cite\\{([\\S \\t]*?)\\}");

    public void generateLib(String bibtex, String encoding) {
        try {
            FileOutputStream fos = new FileOutputStream("bibligraphy.tex");
            OutputStreamWriter out = new OutputStreamWriter(fos, encoding);
            out.write(bibtex);
            out.close();
        } catch (IOException ex) {
            System.err.println(ex.getMessage());
        }
    }

    public List<String> parseFiles(File[] files, String encoding) {
        Set<String> result = new HashSet<>();
        for (File file : files) {
            try {
                result.addAll(parseFile(file, encoding));
            } catch (FileNotFoundException ex) {
                System.err.println(ex.getMessage());
            }
        }
        return new LinkedList<>(result);
    }

    public List<String> parseFile(File texFile, String encoding) throws FileNotFoundException {
        Scanner scan = new Scanner(texFile, encoding);
        Set<String> foundCitations = new HashSet<>();
        String line;
        try {
            line = scan.nextLine();
        } catch (NoSuchElementException exception) {
            return new LinkedList<>();
        }
        Matcher matcher;
        while (true) {
            matcher = pattern.matcher(line);
            if (matcher.find() && matcher.group(1) != null) {
                StringTokenizer st = new StringTokenizer(matcher.group(1), ",");
                while (st.hasMoreTokens()) {
                    foundCitations.add(st.nextToken().trim());
                }
            }
            try {
                line = scan.nextLine();
            } catch (NoSuchElementException exception) {
                break;
            }
        }
        scan.close();
        return new LinkedList<>(foundCitations);
    }
}
